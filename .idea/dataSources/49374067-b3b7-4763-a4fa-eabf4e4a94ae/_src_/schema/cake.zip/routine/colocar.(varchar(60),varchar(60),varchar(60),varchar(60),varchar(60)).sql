CREATE PROCEDURE colocar(IN nome  VARCHAR(60), IN usuario VARCHAR(60), IN mail VARCHAR(60), IN senha VARCHAR(60),
                         IN regra VARCHAR(60))
  BEGIN 
    INSERT INTO users(name, username, email, password, role, created, modified) 
      VALUES (nome, usuario, mail, senha, regra, NOW(), NOW());
  END;
